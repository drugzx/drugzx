#!/usr/bin/python
# -*- coding: utf-8 -*-

# Edite By Programmer Sawim
# Edite By Programmer Vortex
# For Quiz BoT © 2020

reload(sys).setdefaultencoding("utf-8")


def known(type, jid, nick, text):
	count = 10
	if '\n' in text:
		try:
			t_count = text.split('\n')[1].strip().lower()
			if t_count == 'all': count = 0
			else: count = int(t_count)
		except: pass
		text = text.split('\n',1)[0]
	if not text.strip(): text = nick
	real_jid = cur_execute_fetchone('select jid from age where room=%s and (nick=%s or jid=%s) order by status,-time',(jid,text,text.lower()))
	if real_jid:
		if count: lst = cur_execute_fetchall('select nick from age where room=%s and jid=%s and nick!=%s order by status,-time limit %s',(jid,real_jid[0],text,count))
		else: lst = cur_execute_fetchall('select nick from age where room=%s and jid=%s and nick!=%s order by status,-time',(jid,real_jid[0],text))
		if lst: nicks = ', '.join([t[0] for t in lst])
		else: nicks = text
		if text == nick: msg = '%s %s' % (L('أنا أعرفك بهذه الأسماء [:-}\n','%s/%s'%(jid,nick)),nicks)
		else: msg = '%s %s' % (L('أنا أعرف %s بهذه الأسماء [:-}\n','%s/%s'%(jid,nick)) % text,nicks)
	else: msg = L('لا أعرفه [:-}','%s/%s'%(jid,nick))
	send_msg(type, jid, nick, msg)

global execute

execute = [(7, 'القاب'.decode('utf8'), known, 2, 'Show user\'s nick changes.\nknown <nick>\n[count|all]')]
