﻿#!/usr/bin/python
# -*- coding: utf-8 -*-

# Edite By Programmer Sawim
# Edite By Programmer Vortex
# For Quiz BoT © 2020

reload(sys).setdefaultencoding("utf-8")


def bot_shutdown(type, jid, nick, text, reason, xtype):
	global game_over,bot_exit_type
	StatusMessage = L('%s بأمر من %s','%s/%s'%(jid,nick)) % (reason, nick)
	if text != '': StatusMessage += ', ' + L('\nالســـبــب: %s','%s/%s'%(jid,nick)) % text
	send_presence_all(StatusMessage)
	bot_exit_type, game_over = xtype, True

def bot_exit(type, jid, nick, text):
	bot_shutdown(type, jid, nick, text, L('\nايقاف تشغيل','%s/%s'%(jid,nick)), 'exit')

def bot_restart(type, jid, nick, text):
	bot_shutdown(type, jid, nick, text, L('\nاعادة تشغيل','%s/%s'%(jid,nick)), 'restart')

def bot_soft_update(type, jid, nick, text):
	global plugins_reload
	caps_and_send(xmpp.Presence(show='dnd', status=L('Soft update activated!','%s/%s'%(jid,nick)), priority=Settings['priority']))
	plugins_reload = True
	while not game_over and plugins_reload: time.sleep(1)
	if GT('soft_update_resend_hash'):
		pprint('*** Send new hash in to rooms','bright_green')
		cnf = cur_execute_fetchall('select * from conference;')
		for tocon in cnf:
			if tocon[1]: pprint('->- %s | pass: %s' % tocon,'green')
			else: pprint('->- %s' % tocon[0],'green')
			zz = join(tocon)
	if Settings['status'] == 'online': caps_and_send(xmpp.Presence(status=Settings['message'], priority=Settings['priority']))
	else: caps_and_send(xmpp.Presence(show=Settings['status'], status=Settings['message'], priority=Settings['priority']))
	send_msg(type, jid, nick, L('Soft update finished! Plugins loaded: %s. Commands: %s','%s/%s'%(jid,nick)) % (len(plugins)+1,len(comms)))

global execute

execute = [(9, 'ايقاف-تشغيل'.decode('utf8'), bot_exit, 2, 'ايقاف البوت عن العمل'),
	 (9, 'ريستارت'.decode('utf8'), bot_restart, 2, 'اعادة تشغيل البوت1')]
