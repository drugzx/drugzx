#!/usr/bin/python
# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------- #
#                                                                             #
#    Smart Filter Bot By Sawim                                                #
#    Copyright (C) 2020 # sawim.sy@gmail.com                                  #
#                                                                             #
#                                                                             #
# --------------------------------------------------------------------------- #
# Bot SmartFilter For Chat-Sy Edit By Sawim

reload(sys).setdefaultencoding("utf-8")

JIDCATCHER_DEFAULT_LIMIT = 10

def info_search(type, jid, nick, text):
	msg = L('اكتب جزء من الريسورس او الحساب بدون اسم السيرفر لاقوم بالتحري عنه','%s/%s'%(jid,nick))
	if text:
		if '\n' in text:
			text,lim = text.split('\n',1)
			try:
				lim = int(lim)
				if lim < 100 or lim > 1: raise
			except: lim = JIDCATCHER_DEFAULT_LIMIT
		else: lim = JIDCATCHER_DEFAULT_LIMIT
		cur_execute('delete from jid where server ilike %s',('<temporary>%',))
		ttext = '%%%s%%' % text
		tma = cur_execute_fetchall('select * from jid where login ilike %s or server ilike %s or resourse ilike %s order by login limit %s',(ttext,ttext,ttext,lim))
		if tma: msg = '%s\n%s' % (L('##[نتائج التحري]##','%s/%s'%(jid,nick)),'\n'.join(['%s. %s@%s/%s' % tuple([tma.index(tt)+1]+list(tt)) for tt in tma]))
		else: msg = L('\'%s\' لم يتم العثور على شيئ :-(','%s/%s'%(jid,nick)) % text
	send_msg(type, jid, nick, msg)

def info_res(type, jid, nick, text):
	cur_execute('delete from jid where server ilike %s',('<temporary>%',))
	if text.lower() == 'count':
		tlen = cur_execute_fetchall('select count(*) from (select resourse,count(*) from jid group by resourse) tmp;')[0][0]
		text,jidbase = '',''
	else:
		text1 = '%%%s%%' % text
		tlen = cur_execute_fetchall('select count(*) from (select resourse,count(*) from jid where resourse ilike %s group by resourse) tmp;',(text1,))[0][0]
		jidbase = cur_execute_fetchall('select resourse,count(*) from jid where resourse ilike %s group by resourse order by -count(*),resourse limit %s',(text1,JIDCATCHER_DEFAULT_LIMIT))
	if not tlen: msg = L('\'%s\' غير موجود','%s/%s'%(jid,nick)) % text
	else:
		if text: msg = L('##[نتائج الريسورس]## %s','%s/%s'%(jid,nick)) % tlen
		else: msg = L('##[جميع الريسورسات]## %s','%s/%s'%(jid,nick)) % tlen
		if jidbase: msg += '\n%s' % '\n'.join(['%s. %s\t%s' % tuple([jidbase.index(jj)+1]+list(jj)) for jj in jidbase])
	send_msg(type, jid, nick, msg)

def info_serv(type, jid, nick, text):
	cur_execute('delete from jid where server ilike %s',('<temporary>%',))

	if '\n' in text:
		text,lim = text.split('\n',1)
		try:
			lim = int(lim)
			if lim > 100 or lim < 1: raise
		except: lim = JIDCATCHER_DEFAULT_LIMIT
	else: lim = JIDCATCHER_DEFAULT_LIMIT
	
	if text == 'count':
		tlen = cur_execute_fetchone('select count(*) from (select server,count(*) from jid group by server) tmp;')[0]
		text,jidbase = '',''
	else:
		text1 = '%%%s%%' % text
		if base_type == 'pgsql': reqv = 'select * from (select row_number() over(order by -count(*)),server,count(*) from jid group by server order by -count(*),server) tmp where tmp.server ilike %s order by tmp.row_number;'
		elif base_type == 'mysql': reqv = 'select * from (select @i:=@i+1 as itr,sr,cn from (select server as sr,count(*) as cn from jid group by server order by -count(*)) as t1,(select @i:=0) as t2) as t3 where sr like %s'
		elif base_type == 'sqlite3':
			# TODO: It's works not properly. Need fix record's numbers!
			reqv = 'select row_number(),sr,cn from (select server as sr,count(*) as cn from jid group by server order by -cn) where sr like %s order by -cn'
		jidbase = cur_execute_fetchall(reqv,(text1,))
		tlen = len(jidbase)
		jidbase = jidbase[:lim]
	if not tlen: msg = L('\'%s\' غير موجود','%s/%s'%(jid,nick)) % text
	else:
		if text: msg = L('##[نتائج البحث]## %s','%s/%s'%(jid,nick)) % tlen
		else: msg = L('##[جميع السيرفرات]## %s','%s/%s'%(jid,nick)) % tlen
		if jidbase: msg = '%s\n%s' %(msg,'\n'.join(['%s. %s [%s]' % (int(jj[0]),jj[1],jj[2]) for jj in jidbase]))
	send_msg(type, jid, nick, msg)

#room number date

def info_top(type, jid, nick, text):
	if text: room = text
	else: room = getRoom(jid)
	cnf = cur_execute_fetchone('select count ,time from top where room=%s',(room,))
	if cnf: msg = L('Max count of members: %s %s','%s/%s'%(jid,nick)) % (cnf[0], '(%s)' % disp_time(cnf[1],'%s/%s'%(jid,nick)))
	else: msg = L('Statistic not found!','%s/%s'%(jid,nick))
	send_msg(type, jid, nick, msg)

def jidcatcher_presence(room,jid,nick,type,text):
	if jid != 'None' and not jid.startswith('<temporary>'):
		tmp = (getName(jid),getServer(jid),getResourse(jid))
		try:
			tmpp = cur_execute_fetchone('select login from jid where login=%s and server=%s and resourse=%s',tmp)
			if not tmpp: cur_execute('insert into jid values (%s,%s,%s)', tmp)
		except: pass

		cnt = len(['' for t in megabase if t[0]==room])
		cnf = cur_execute_fetchone('select count from top where room=%s',(room,))
		if cnf:
			if cnt > cnf[0]: cur_execute('update top set count =%s, time=%s where room=%s;',(cnt,int(time.time()),room))
		else: cur_execute('insert into top values (%s,%s,%s);',(room,cnt,int(time.time())))

global execute, presence_control

presence_control = [jidcatcher_presence]

execute = [(8, 'ريسورسات'.decode('utf-8'), info_res, 2, 'معرفة الريسورسات وعددها التي دخلت الى الروم'),
		   (9, 'سيرفرات'.decode('utf-8'), info_serv, 2, 'معرفة السيرفرات المتصل عليها البوت'),
		   (8, 'تحري'.decode('utf-8'), info_search, 2, 'التحري عن حساب كامل مع الريسوورس الخاص به')]
